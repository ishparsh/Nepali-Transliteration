from .app import nep_to_rom
from .bhandar import dict_value


print(nep_to_rom("म नेपाल मा बस्छु ।"))